-- enply script used like dummy by system control

function initialize(a, b)

end